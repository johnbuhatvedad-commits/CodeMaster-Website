from pathlib import Path
import re, shutil
p=Path('/mnt/data/cmwork/app/src/main/assets/index.html')
s=p.read_text()
# Match website's simple blue-violet code mark and remove Tools button.
s=s.replace('.brand{font-size:21px;font-weight:850;display:flex;align-items:center;gap:9px}.brandLogo{width:36px;height:36px;border-radius:9px;object-fit:cover}.brandAccent{color:#72aaff}', '.brand{font-size:21px;font-weight:850;display:flex;align-items:center;gap:9px}.brandLogo{width:36px;height:36px;border-radius:10px;object-fit:cover}.brandAccent{color:#72aaff}')
s=s.replace('.toolBox{margin-top:12px;padding:12px;border:1px solid var(--line);border-radius:10px;background:#10182b}.features', '.toolBox{margin-top:12px;padding:12px;border:1px solid var(--line);border-radius:10px;background:#10182b}.assistant-launch{position:fixed;right:14px;bottom:16px;z-index:8;border:1px solid #586fa7;border-radius:999px;padding:10px 14px;background:linear-gradient(110deg,#568cff,#985cff);color:white;font-weight:750;box-shadow:0 8px 28px #0008}.assistant-card{position:fixed;right:12px;bottom:70px;z-index:7;width:min(440px,calc(100vw - 24px));max-height:72vh;overflow:auto;box-shadow:0 18px 50px #000b}.assistant-card .outbody{max-height:220px;overflow:auto}.features')
s=s.replace('<button onclick="togglePanel(\'settingsPanel\')">Customize</button><button onclick="togglePanel(\'toolsPanel\')">Tools</button><button onclick="togglePanel(\'assistantPanel\')">AI Assistant</button>', '<button onclick="togglePanel(\'settingsPanel\')">Customize</button>')
# Remove whole Quick Tools section.
s=re.sub(r'<section id="toolsPanel".*?</section>\n', '', s, flags=re.S)
# Replace assistant section with small, labeled floating Code Help entry point and copy button.
start=s.index('<section id="assistantPanel"')
end=s.index('</section>', start)+len('</section>')
assistant='''<button class="assistant-launch" onclick="togglePanel('assistantPanel')" aria-controls="assistantPanel" aria-expanded="false">Code Help</button>
<section id="assistantPanel" class="output assistant-card" style="display:none;padding:14px">
 <div style="display:flex;align-items:center;justify-content:space-between;gap:12px"><b>Code Help</b><button onclick="togglePanel('assistantPanel')" aria-label="Close code help">✕</button></div>
 <p class="status">Use this helper according to your class rules. Offline mode provides starter templates. Online AI activates automatically only when the app developer has connected a secure service.</p>
 <textarea id="aiPrompt" rows="3" placeholder="Describe what you want your program to do..." style="width:100%;padding:11px;border-radius:8px;background:#0c1426;color:white;border:1px solid #35496f"></textarea>
 <div class="toolbar"><button class="primary" onclick="generateWithAssistant()">Generate code</button><button onclick="copyAssistantCode()">Copy code</button><button onclick="insertAssistantResult()">Insert into editor</button><button onclick="runAssistantCode()">Insert & Run</button></div>
 <div id="aiExplanation" class="status">Choose a language, then describe what you want to build.</div><pre id="aiResult" class="outbody">Generated code will appear here.</pre>
</section>'''
s=s[:start]+assistant+s[end:]
# remove old converter and text tool JS block
s=re.sub(r'\nfunction showTool\(id\).*?\n\nfunction init\(\)', '\nfunction init()', s, flags=re.S)
# Improve assistant: don't silently return unrelated starter code for unsupported requests.
s=s.replace(" if(/hello|print|output|starter|basic/.test(p))return hello;", " if(/hello|print|output|starter|basic/.test(p))return hello;\n if(isCss && /background|style|color|design|css/.test(p))return 'body {\\n  font-family: Arial, sans-serif;\\n  background: #eef4ff;\\n  color: #18345c;\\n  padding: 24px;\\n}\\nh1 { color: #286bd6; }';\n if(isHtml && /button|form|profile|portfolio|web page|website/.test(p))return '<!doctype html>\\n<html>\\n<head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>My Page</title></head>\\n<body>\\n  <h1>Welcome!</h1>\\n  <p>My first web page.</p>\\n  <button onclick=\"alert(\\'Hello!\\')\">Click me</button>\\n</body>\\n</html>';" )
s=s.replace(" return hello;\n}\nfunction offlineHelp(prompt,lang){\n const generated=codeForRequest(prompt,lang);\n return generated;\n}", " return null;\n}\nfunction offlineHelp(prompt,lang){ return codeForRequest(prompt,lang); }")
# Replace mode selection handler and generator function with auto-online/no user URL, reliable code fence cleanup.
start=s.index("document.getElementById('aiMode')")
end=s.index("function runAssistantCode()", start)
new='''function cleanGeneratedCode(value){
 let text=String(value||'').trim();
 const match=text.match(/^```(?:[a-zA-Z0-9_+-]+)?\\s*\\n([\\s\\S]*?)\\n```$/);
 if(match) text=match[1];
 return text;
}
async function generateWithAssistant(){
 const prompt=document.getElementById('aiPrompt').value.trim(),lang=language.value;
 const result=document.getElementById('aiResult'),explain=document.getElementById('aiExplanation');
 assistantCode='';
 if(!prompt){explain.textContent='Type a short description first.';result.textContent='';return;}
 result.textContent='Generating...';
 try{
  const endpoint=window.CODEMASTER_AI_ENDPOINT||'';
  if(/^https:\\/\\//i.test(endpoint)){
   const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt,language:lang,currentCode:code.value})});
   if(!response.ok)throw new Error('The AI service returned an error (HTTP '+response.status+').');
   const data=await response.json();
   assistantCode=cleanGeneratedCode(data.code||data.output||data.response||'');
   if(!assistantCode)throw new Error('The AI service returned no code.');
   explain.textContent=String(data.explanation||'Online AI response received. Check the code before running.');
  }else{
   assistantCode=cleanGeneratedCode(offlineHelp(prompt,lang)||'');
   if(!assistantCode){result.textContent='';explain.textContent='The offline helper does not have a matching template for that request. It will not show unrelated code. Full AI generation is unavailable until the app developer connects an online AI service.';return;}
   explain.textContent='Offline starter template generated. It is not a full AI model, so review and test the code.';
  }
  result.textContent=assistantCode;
 }catch(e){assistantCode='';result.textContent='';explain.textContent='Code Help could not generate code: '+e.message;}
}
async function copyAssistantCode(){
 if(!assistantCode){document.getElementById('aiExplanation').textContent='Generate code first.';return;}
 try{
  if(navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(assistantCode);
  else {const t=document.createElement('textarea');t.value=assistantCode;t.style.position='fixed';t.style.opacity='0';document.body.appendChild(t);t.select();const ok=document.execCommand('copy');t.remove();if(!ok)throw new Error('Copy unavailable');}
  document.getElementById('aiExplanation').textContent='Code copied. You can paste it into the editor.';
 }catch(e){document.getElementById('aiExplanation').textContent='Copy was blocked on this device. Use Insert into editor instead.';}
}
'''
s=s[:start]+new+s[end:]
# update README claims
p.write_text(s)
# Remove obsolete tool CSS class only if no longer used by tools; retain for C/C++ input box.
# Update README to state exact functionality and limitations.
readme=Path('/mnt/data/cmwork/README.md')
r=readme.read_text()
r=r.replace('- Added simple built-in calculator, unit converter, and text tools. These do not ask for a URL.\n','- Removed the Quick Tools panel as requested.\n')
r=r.replace('- Improved the assistant panel: generated code is shown separately, can be inserted, or inserted and run.\n','- Added a small, clearly labeled Code Help launcher; generated code can be copied, inserted, or inserted and run.\n')
r=r.replace('- Added offline starter-code templates for common beginner requests. This is a template helper, not a full AI model.\n','- Offline starter-code templates return only for supported request patterns; unmatched prompts no longer receive unrelated sample code. This is a template helper, not a full AI model.\n')
r=r.replace('- Full conversational AI is not included or connected. The offline helper uses templates. A real AI assistant requires a secure backend and an AI service credential; do not put private API keys inside the APK or share them in chat. The online endpoint field is a developer configuration, not something normal app users should need to fill in.\n','- Full conversational AI is not included or connected. The app does not ask users to enter a URL. Online AI activates only if the developer configures a secure backend endpoint in the app build. The offline helper uses limited templates.\n')
r += '\n## Verification status for this update\n\nThe source was checked for JavaScript syntax and ZIP integrity. This environment cannot build and install the Android APK or test every runtime on a physical phone. HTML/CSS preview and JavaScript run locally; Python uses the bundled Chaquopy runtime; Java uses Janino (subset); C/C++ use the online compiler and therefore require internet. Offline C/C++ execution is not included.\n'
readme.write_text(r)
