package com.codemaster.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient.FileChooserParams;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import org.codehaus.janino.SimpleCompiler;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileChooserCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(9,14,29));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(9,14,29));
        if (!Python.isStarted()) Python.start(new AndroidPlatform(this));

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setDefaultTextEncodingName("UTF-8");
        web.addJavascriptInterface(new NativeBridge(), "CodeMaster");
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType(params != null && params.getAcceptTypes() != null && params.getAcceptTypes().length > 0
                        && params.getAcceptTypes()[0].startsWith("image/") ? "image/*" : "*/*");
                try {
                    startActivityForResult(Intent.createChooser(pick, "Choose a picture or file"), 72);
                    return true;
                } catch (Exception e) {
                    fileChooserCallback = null;
                    Toast.makeText(MainActivity.this, "Unable to open file picker", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/index.html");
    }

    public class NativeBridge {
        @JavascriptInterface public void runPython(String source) {
            new Thread(() -> {
                String result;
                try {
                    result = Python.getInstance().getModule("codemaster_runner").callAttr("run", source).toString();
                } catch (Throwable e) {
                    result = "Python error: " + rootMessage(e);
                }
                send("Python", result);
            }).start();
        }

        @JavascriptInterface public void runRemoteCompiler(String language, String source, String input) {
            new Thread(() -> {
                String result;
                HttpURLConnection connection = null;
                try {
                    String compiler = "cpp".equals(language) ? "g++-15" : "gcc-15";
                    URL url = new URL("https://api.onlinecompiler.io/api/guest/run-code/");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(15000);
                    connection.setReadTimeout(25000);
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                    JSONObject body = new JSONObject();
                    body.put("compiler", compiler);
                    body.put("code", source);
                    body.put("input", input == null ? "" : input);
                    byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
                    try (OutputStream os = connection.getOutputStream()) { os.write(payload); }
                    int status = connection.getResponseCode();
                    java.io.InputStream stream = status >= 200 && status < 300
                            ? connection.getInputStream() : connection.getErrorStream();
                    StringBuilder response = new StringBuilder();
                    try (java.io.BufferedReader reader = new java.io.BufferedReader(
                            new java.io.InputStreamReader(stream, StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null) response.append(line);
                    }
                    JSONObject data = new JSONObject(response.toString());
                    String stdout = data.optString("output", "");
                    String stderr = data.optString("error", "");
                    String state = data.optString("status", "");
                    result = (stdout.isEmpty() ? "" : stdout)
                            + (stderr.isEmpty() ? "" : (stdout.isEmpty() ? "" : "\n") + stderr);
                    if (result.isEmpty()) result = state.equals("success")
                            ? "Program finished with no output." : "Compiler returned no output. Status: " + state;
                    if (status < 200 || status >= 300) result = "Compiler service error (HTTP " + status + "): " + result;
                } catch (Exception e) {
                    result = "C/C++ compiler connection failed: " + e.getMessage()
                            + "\nCheck your internet connection and try again.";
                } finally {
                    if (connection != null) connection.disconnect();
                }
                send("C/C++", result);
            }).start();
        }

        @JavascriptInterface public void runJava(String source) {
            new Thread(() -> {
                String result;
                PrintStream old = System.out;
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                try (PrintStream capture = new PrintStream(bytes, true, "UTF-8")) {
                    System.setOut(capture);
                    SimpleCompiler compiler = new SimpleCompiler();
                    compiler.cook(source);
                    Class<?> mainClass = compiler.getClassLoader().loadClass("Main");
                    Method main = mainClass.getMethod("main", String[].class);
                    main.invoke(null, (Object) new String[0]);
                    result = bytes.toString("UTF-8");
                    if (result.isEmpty()) result = "Program finished with no output.";
                } catch (Throwable e) {
                    result = "Java error: " + rootMessage(e);
                } finally {
                    System.setOut(old);
                }
                send("Java", result);
            }).start();
        }

        @JavascriptInterface public void saveText(String filename, String content) {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TITLE, filename);
                pendingSave = content;
                try { startActivityForResult(intent, 71); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Cannot open save dialog", Toast.LENGTH_SHORT).show(); }
            });
        }

        private String pyQuote(String input) {
            // Python literal encoded safely as a JSON-compatible quoted string.
            return JSONObjectQuote.quote(input);
        }

        private void send(String language, String output) {
            String payload = JSONObjectQuote.quote(language + "\n" + output);
            runOnUiThread(() -> {
                if (web != null) web.evaluateJavascript("window.nativeResult(" + payload + ")", null);
            });
        }
    }

    private String pendingSave = null;

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 72) {
            if (fileChooserCallback != null) {
                Uri[] result = resultCode == RESULT_OK && data != null && data.getData() != null
                        ? new Uri[]{data.getData()} : null;
                fileChooserCallback.onReceiveValue(result);
                fileChooserCallback = null;
            }
            return;
        }
        if (requestCode == 71 && resultCode == RESULT_OK && data != null && pendingSave != null) {
            try (java.io.OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                os.write(pendingSave.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, "File saved", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            } finally { pendingSave = null; }
        }
    }

    private static String rootMessage(Throwable t) {
        while (t.getCause() != null) t = t.getCause();
        return t.toString();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    // Minimal JSON string quoting for safe JS callback arguments.
    static class JSONObjectQuote {
        static String quote(String s) {
            StringBuilder b = new StringBuilder("\"");
            for (int i=0;i<s.length();i++) {
                char c=s.charAt(i);
                switch(c) {
                    case '"': b.append("\\\""); break;
                    case '\\': b.append("\\\\"); break;
                    case '\n': b.append("\\n"); break;
                    case '\r': b.append("\\r"); break;
                    case '\t': b.append("\\t"); break;
                    default:
                        if (c < 32) b.append(String.format("\\u%04x",(int)c));
                        else b.append(c);
                }
            }
            return b.append("\"").toString();
        }
    }
}
