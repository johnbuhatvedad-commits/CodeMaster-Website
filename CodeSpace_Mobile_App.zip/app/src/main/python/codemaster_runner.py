import contextlib
import io
import traceback


def run(source):
    output = io.StringIO()
    scope = {"__name__": "__main__"}
    try:
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            exec(compile(source, "<CodeMaster>", "exec"), scope, scope)
    except BaseException:
        traceback.print_exc(file=output)
    result = output.getvalue()
    return result if result else "Program finished with no output."
