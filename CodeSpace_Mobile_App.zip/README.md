# CodeMaster — updated Android source project

## Included in this update
- Added a CodeMaster launcher icon and matching in-app logo.
- Removed the Quick Tools panel as requested.
- Added a small, clearly labeled Code Help launcher; generated code can be copied, inserted, or inserted and run.
- Offline starter-code templates return only for supported request patterns; unmatched prompts no longer receive unrelated sample code. This is a template helper, not a full AI model.
- Kept local execution for HTML/CSS preview, JavaScript, Python (Chaquopy), and the supported Java subset (Janino).
- Kept image selection and local background saving.

## Important language and AI limitations
- C and C++ are selectable and sent to the configured OnlineCompiler.io guest endpoint when Run is pressed. This requires internet and depends on that third-party service being available; offline C/C++ execution is not included.
- Full conversational AI is not included or connected. The app does not ask users to enter a URL. Online AI activates only if the developer configures a secure backend endpoint in the app build. The offline helper uses limited templates.
- Java support uses Janino and is a subset of a full JDK.

## Build
Upload the contents of this project folder to the root of your GitHub repository. Run **Actions → Build CodeMaster Offline APK**, then download the `CodeMaster-debug-APK` artifact. The APK must be installed and tested on a device before calling this build verified.

## Safety note
Only run code you wrote or trust. This is a student learning project, not a hardened code-execution environment.


## C and C++ execution

C (`gcc-15`) and C++ (`g++-15`) are sent to the OnlineCompiler.io guest execution endpoint when Run is pressed. This requires an internet connection. Program input can be entered in the Program input box. The service may apply guest-use limits or change availability. Do not send passwords, personal information, or private source code to the external compiler.

## AI Assistant status

The Code Help button works offline for a limited set of built-in templates. Full conversational AI is not activated in this project yet. Online AI will work only after the developer configures a secure server-side AI endpoint in the app build; users do not enter a URL. Do not put a private AI key directly into a public APK or public source repository.


## Android processor compatibility

The Android build is configured to include both ARM ABIs: `armeabi-v7a` (32-bit) and `arm64-v8a` (64-bit). This targets 32-bit and 64-bit ARM Android phones in one APK. It does not add an offline C/C++ compiler by itself; a compatible compiler toolchain must still be bundled for each ABI and tested on-device.

## Verification status for this update

The source was checked for JavaScript syntax and ZIP integrity. This environment cannot build and install the Android APK or test every runtime on a physical phone. HTML/CSS preview and JavaScript run locally; Python uses the bundled Chaquopy runtime; Java uses Janino (subset); C/C++ use the online compiler and therefore require internet. Offline C/C++ execution is not included.
