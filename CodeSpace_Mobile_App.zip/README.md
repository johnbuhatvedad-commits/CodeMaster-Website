# CodeMaster — updated Android source project

## Included in this update
- Added a CodeMaster launcher icon and matching in-app logo.
- Added simple built-in calculator, unit converter, and text tools. These do not ask for a URL.
- Improved the assistant panel: generated code is shown separately, can be inserted, or inserted and run.
- Added offline starter-code templates for common beginner requests. This is a template helper, not a full AI model.
- Kept local execution for HTML/CSS preview, JavaScript, Python (Chaquopy), and the supported Java subset (Janino).
- Kept image selection and local background saving.

## Important language and AI limitations
- C and C++ are selectable and editable, but this APK source does not include a C/C++ compiler. They cannot run until a compiler service is connected or a native compiler is bundled.
- Full conversational AI is not included or connected. The offline helper uses templates. A real AI assistant requires a secure backend and an AI service credential; do not put private API keys inside the APK or share them in chat. The online endpoint field is a developer configuration, not something normal app users should need to fill in.
- Java support uses Janino and is a subset of a full JDK.

## Build
Upload the contents of this project folder to the root of your GitHub repository. Run **Actions → Build CodeMaster Offline APK**, then download the `CodeMaster-debug-APK` artifact. The APK must be installed and tested on a device before calling this build verified.

## Safety note
Only run code you wrote or trust. This is a student learning project, not a hardened code-execution environment.


## C and C++ execution

C (`gcc-15`) and C++ (`g++-15`) are sent to the OnlineCompiler.io guest execution endpoint when Run is pressed. This requires an internet connection. Program input can be entered in the Program input box. The service may apply guest-use limits or change availability. Do not send passwords, personal information, or private source code to the external compiler.

## AI Assistant status

The offline helper still generates a few starter templates. Full conversational AI is not activated in this project yet. It requires a properly configured AI provider and a secure server-side connection. Do not put a private AI key directly into a public APK or public source repository.


## Android processor compatibility

The Android build is configured to include both ARM ABIs: `armeabi-v7a` (32-bit) and `arm64-v8a` (64-bit). This targets 32-bit and 64-bit ARM Android phones in one APK. It does not add an offline C/C++ compiler by itself; a compatible compiler toolchain must still be bundled for each ABI and tested on-device.
