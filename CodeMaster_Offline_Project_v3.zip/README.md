# CodeMaster Offline Android IDE (v3)

## Current implementation
- HTML: local WebView preview
- CSS: local WebView preview
- JavaScript: local WebView execution
- Python: embedded Chaquopy Python 3.11 runtime
- Java: embedded Janino in-memory Java compiler (Java subset; not a full JDK)
- C and C++: editor, templates, open/save/download only. No offline C/C++ compiler is bundled in this build.

## Why C/C++ are not marked as working
A real offline C/C++ compiler needs native compiler binaries and runtime libraries built for Android ABIs (such as arm64-v8a), packaged with the app, and tested on target devices. This project deliberately does not fake compilation or silently send code to an online service.

## Build
1. Upload the contents of this folder to your GitHub repository root.
2. Push to main/master or run **Actions → Build CodeMaster Offline APK**.
3. Download the `CodeMaster-debug-APK` artifact and extract `app-debug.apk`.

The first build downloads Android/Gradle/Chaquopy dependencies during compilation. Once installed, the included Python and Java engines execute locally without network access. The app does not require internet permission.

## Important runtime notes
- Janino supports a Java language subset and does not provide the full Java standard library or `javac`.
- Java source must define `public class Main` with `public static void main(String[] args)`.
- Python output is captured; interactive stdin and advanced terminal behavior are not implemented.
- Java code runs in-process. Only run code you wrote or trust. This is a learning app, not a hardened security sandbox.
- C/C++ need a separately packaged Android-native compiler toolchain before those languages can be called fully supported.
