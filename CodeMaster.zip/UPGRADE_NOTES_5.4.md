# CodeMaster 5.4 – Syntax highlighting and editor scrolling fix

- Replaced chained syntax-highlighting replacements with a single-pass tokenizer over the original source. Generated `<span class=...>` markup is never reprocessed as source, preventing visible fragments such as `class=\"tok-str\"` from leaking into the editor.
- Added `wrap=\"off\"` to the code textarea so long lines remain on one line and can be horizontally scrolled.
- Explicitly enabled two-axis editor overflow and touch momentum scrolling on Android WebView.
- Kept line numbers and the syntax-highlight overlay synchronized with the editable textarea's vertical and horizontal scroll positions.
- Preserves the v5.3 hybrid Java execution implementation.

## Validation
- Extracted the inline JavaScript and ran `node --check` successfully.
- Android Gradle build and physical-device touch/scroll testing have not been performed here. Build and test the APK before release.
