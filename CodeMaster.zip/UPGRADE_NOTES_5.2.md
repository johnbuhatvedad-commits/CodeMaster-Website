# CodeMaster v5.2 – Java Runtime Fix

- Removed Janino's in-process class loading path. Android ART does not support loading ordinary JVM `.class` files through this path, which caused `UnsupportedOperationException: can't load this type of class file`.
- Java now uses the existing guest compiler endpoint with compiler id `openjdk-25`.
- Java execution therefore requires an internet connection. Java source is sent to the compiler service when Run is pressed. Do not submit private or sensitive code. Guest service rate limits and availability may apply.
- HTML/CSS preview, JavaScript and Python remain local. C/C++ continue to use the existing online compiler path.
- This is a source update; build and test the APK before distributing it.
