# CodeMaster 5.3 – Hybrid Java execution update

## Java execution design
- Removed Janino's ordinary JVM class-loading path, which failed on Android ART.
- Added an offline beginner-Java interpreter using BeanShell 2.1.1. It extracts and interprets statements inside `main(...)`; it is not a full `javac` compiler and does not support every Java feature.
- Runs the offline interpreter in a dedicated Android `isolatedProcess` service, separate from the app process and without the app's permissions.
- Added a 4-second offline execution limit and 64 KB source / 32 KB output limits.
- Added online OpenJDK 25 execution using OnlineCompiler.io's guest endpoint. Auto mode tries offline first and asks the user before sending source/input online. Online mode also asks before sending.
- Online guest execution needs internet and is subject to the provider's guest limits (documented as 20 runs per address per hour and a 5-second guest execution cap). For a production release, use a backend with a server-side API key; never put a private API key in the APK.
- Added Java stdin input box and selectable modes: Auto, Offline only, Online OpenJDK.

## Important limitations
- Offline Java is a beginner subset, not full Java SE. Advanced libraries, custom class definitions, lambdas, and many modern language features may require Online OpenJDK.
- Online runs transmit the user's source code and input to OnlineCompiler.io only after explicit confirmation in the app.
- This source archive has not been built or tested on a physical Android device in this environment. Run the GitHub Actions build, install the APK, and test the supplied checks before publishing.

## Build
Use the included GitHub Actions workflow or Android Studio. The workflow uploads a debug APK artifact.
