
const examples={
html:'<!doctype html>\n<html>\n<body>\n  <h1>Hello, CodeMaster!</h1>\n  <p>My first web page.</p>\n</body>\n</html>',
css:'body {\n  font-family: Arial, sans-serif;\n  background: #eef4ff;\n  color: #18345c;\n  padding: 24px;\n}\nh1 { color: #286bd6; }',
javascript:'function greet(name) {\n  return "Hello, " + name + "!";\n}\nconsole.log(greet("CodeMaster"));',
python:'print("Hello, CodeMaster!")',
java:'public class Main {\n    public static void main(String[] args) {\n        System.out.println("Hello, CodeMaster!");\n    }\n}',
c:'#include <stdio.h>\nint main(void) {\n    printf("Hello, CodeMaster!\\n");\n    return 0;\n}',
cpp:'#include <iostream>\nint main() {\n    std::cout << "Hello, CodeMaster!" << std::endl;\n    return 0;\n}'
};
const extensions={html:'html',css:'css',javascript:'js',python:'py',java:'java',c:'c',cpp:'cpp'};
const language=document.getElementById('language'),code=document.getElementById('code'),numbers=document.getElementById('numbers'),output=document.getElementById('output'),preview=document.getElementById('preview');
let currentName='main.html', files=[{name:'main.html',lang:'html',text:examples.html}],active=0;
const WORKSPACE_KEY='codemaster_professional_workspace_v5';
let saveTimer=null;
function refreshLines(){let n=code.value.split('\n').length;numbers.textContent=Array.from({length:n},(_,i)=>i+1).join('\n');document.getElementById('linestatus').textContent=n+' lines'}
function sync(){if(!files[active])return;files[active].text=code.value;files[active].lang=language.value;files[active].name=currentName;queueWorkspaceSave()}
function queueWorkspaceSave(){clearTimeout(saveTimer);saveTimer=setTimeout(persistWorkspace,350)}
function persistWorkspace(){try{localStorage.setItem(WORKSPACE_KEY,JSON.stringify({files,active,currentName,updatedAt:new Date().toISOString()}));let m=document.getElementById('workspaceMeta');if(m)m.textContent='Local workspace · Saved automatically at '+new Date().toLocaleTimeString()}catch(e){let m=document.getElementById('workspaceMeta');if(m)m.textContent='Autosave unavailable: device storage may be full.'}}
function restoreWorkspace(){try{let raw=localStorage.getItem(WORKSPACE_KEY);if(!raw)return false;let w=JSON.parse(raw);if(!w||!Array.isArray(w.files)||!w.files.length)return false;files=w.files.filter(f=>f&&typeof f.name==='string'&&typeof f.text==='string'&&extensions[f.lang]);if(!files.length)return false;active=Math.min(Math.max(0,Number(w.active)||0),files.length-1);currentName=files[active].name;return true}catch(e){return false}}
function updateWorkspaceMeta(){let m=document.getElementById('workspaceMeta');if(m)m.textContent=files.length+' file(s) · Autosave enabled · Stored on this device'}
function switchFile(i){sync();active=i;let f=files[i];currentName=f.name;language.value=f.lang;code.value=f.text;document.getElementById('filename').textContent=currentName;refreshLines();renderTabs();updateHighlight()}
function renderTabs(){document.getElementById('tabs').innerHTML=files.map((f,i)=>'<button class="tab '+(i===active?'active':'')+'" onclick="switchFile('+i+')">'+escapeHtml(f.name)+'</button>').join('');updateWorkspaceMeta()}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function changeLanguage(){sync();let l=language.value;document.getElementById('cppInputPanel').style.display=(l==='c'||l==='cpp')?'block':'none';document.getElementById('javaRunPanel').style.display=l==='java'?'block':'none';currentName='main.'+extensions[l];files[active]={name:currentName,lang:l,text:examples[l]};code.value=examples[l];document.getElementById('filename').textContent=currentName;refreshLines();renderTabs();output.textContent='Ready to run '+l+'.';updateHighlight()}
language.addEventListener('change',changeLanguage);code.addEventListener('input',()=>{refreshLines();sync();updateHighlight()});code.addEventListener('scroll',()=>{numbers.scrollTop=code.scrollTop;highlight.scrollTop=code.scrollTop;highlight.scrollLeft=code.scrollLeft;});
code.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();saveFile();return}if((e.ctrlKey||e.metaKey)&&e.key==='Enter'){e.preventDefault();runCode();return}if(e.key==='Tab'){e.preventDefault();let p=code.selectionStart;code.setRangeText('    ',p,code.selectionEnd,'end');refreshLines();sync()}else if(['{','(','[','\"',"'"].includes(e.key)){let pairs={'{':'}','(':')','[':']','\"':'\"',"'":"'"};let p=code.selectionStart,sel=code.selectionEnd;if(sel===p){e.preventDefault();code.setRangeText(e.key+pairs[e.key],p,p,'end');code.setSelectionRange(p+1,p+1);refreshLines();sync()}}});
function nativeResult(value){let i=value.indexOf('\n');let lang=value.slice(0,i),result=value.slice(i+1);if(lang==='Java Offline Unsupported'&&language.value==='java'&&document.getElementById('javaMode').value==='auto'){output.textContent='[Java Offline]\n'+result;document.getElementById('status').textContent='Offline subset limit reached';if(confirm('Offline Java cannot run this program. Send your code to OnlineCompiler.io to run it with OpenJDK? Your source and input will leave this device.')){runJavaOnline(code.value,document.getElementById('javaInput').value)}return;}output.textContent='['+lang+']\n'+result;document.getElementById('status').textContent='Finished · '+lang}
function runJavaOnline(src,input){if(!confirm('Online Java sends your source code and program input to OnlineCompiler.io for execution. Do not send passwords, private information, or confidential code. Continue?'))return;output.textContent='Sending Java to the online OpenJDK compiler...';CodeMaster.runRemoteCompiler('java',src,input||'')}
function runCode(){sync();let l=language.value,src=code.value;preview.style.display='none';
 if(l==='html'){preview.style.display='block';preview.srcdoc=src;output.textContent='HTML preview refreshed.';return}
 if(l==='css'){preview.style.display='block';preview.srcdoc='<!doctype html><html><head><style>'+src+'</style></head><body><h2>CSS Preview</h2><p>Edit your CSS to style this page.</p></body></html>';output.textContent='CSS preview refreshed.';return}
 if(l==='javascript'){try{let logs=[];let safeConsole={log:(...a)=>logs.push(a.map(x=>typeof x==='object'?JSON.stringify(x):String(x)).join(' ')),error:(...a)=>logs.push('Error: '+a.join(' ')),warn:(...a)=>logs.push('Warning: '+a.join(' '))};new Function('console',src)(safeConsole);output.textContent=logs.join('\n')||'Executed successfully (no console output).'}catch(e){output.textContent='JavaScript error: '+e.message}return}
 if(l==='python'){if(window.CodeMaster){output.textContent='Running Python offline...';CodeMaster.runPython(src)}else output.textContent='Python runtime is unavailable in this build.';return}
 if(l==='java'){let mode=document.getElementById('javaMode').value,input=document.getElementById('javaInput').value;if(!window.CodeMaster){output.textContent='Java runtime is unavailable in this build.';return;}if(mode==='online'){runJavaOnline(src,input);return;}output.textContent='Running Java in the isolated offline interpreter...';CodeMaster.runJavaOffline(src,input);return}
 if(l==='c'||l==='cpp'){if(window.CodeMaster){document.getElementById('cppInputPanel').style.display='block';output.textContent='Sending code to the online '+l.toUpperCase()+' compiler...';CodeMaster.runRemoteCompiler(l,src,document.getElementById('cppInput').value);return;}output.textContent='Online C/C++ compiler is unavailable in this build.';return;} output.textContent=l.toUpperCase()+' is not supported for running in this build.'}
function newFile(){sync();let l=language.value,n='untitled'+(files.length+1)+'.'+extensions[l];files.push({name:n,lang:l,text:''});switchFile(files.length-1);code.focus();document.getElementById('status').textContent='New file created: '+n}
function renameActiveFile(){let proposed=prompt('Enter a new file name:',currentName);if(!proposed)return;proposed=proposed.trim();if(!/^[a-zA-Z0-9._-]+$/.test(proposed)){alert('Use only letters, numbers, dots, underscores and hyphens.');return}let lang=Object.keys(extensions).find(k=>proposed.toLowerCase().endsWith('.'+extensions[k]));if(!lang){alert('Use a supported extension: '+Object.values(extensions).join(', '));return}currentName=proposed;files[active].name=proposed;files[active].lang=lang;language.value=lang;document.getElementById('filename').textContent=proposed;renderTabs();persistWorkspace();document.getElementById('status').textContent='Renamed file to '+proposed}
function closeActiveFile(){if(files.length===1){if(!confirm('Close this file and start a fresh file?'))return;files=[{name:'main.'+extensions[language.value],lang:language.value,text:''}];active=0;switchFile(0);persistWorkspace();return}files.splice(active,1);active=Math.max(0,active-1);switchFile(active);persistWorkspace()}
function exportWorkspace(){sync();let payload={app:'CodeMaster',formatVersion:1,exportedAt:new Date().toISOString(),files};let blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});let a=document.createElement('a'),u=URL.createObjectURL(blob);a.href=u;a.download='CodeMaster-Project.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);document.getElementById('status').textContent='Project exported. Keep the JSON file as a backup.'}
document.getElementById('workspaceImport').addEventListener('change',e=>{let f=e.target.files&&e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let data=JSON.parse(String(r.result));if(data.app!=='CodeMaster'||!Array.isArray(data.files))throw new Error('This is not a CodeMaster project backup.');let imported=data.files.filter(x=>x&&typeof x.name==='string'&&typeof x.text==='string'&&extensions[x.lang]);if(!imported.length)throw new Error('No supported source files were found.');if(!confirm('Import '+imported.length+' file(s)? This replaces the current open workspace.'))return;files=imported;active=0;switchFile(0);persistWorkspace();document.getElementById('status').textContent='Project imported successfully.'}catch(err){alert('Import failed: '+err.message)}};r.readAsText(f);e.target.value=''});
function formatCode(){let l=language.value,s=code.value;if(l==='json'){try{s=JSON.stringify(JSON.parse(s),null,2)}catch(e){alert('Could not format: invalid JSON.');return}}else{s=s.split('\n').map(x=>x.replace(/[ \t]+$/g,'')).join('\n');if(!s.endsWith('\n'))s+='\n'}code.value=s;refreshLines();sync();updateHighlight();document.getElementById('status').textContent='Basic formatting applied. Language-aware formatting is not installed.'}
function findInCode(){let q=prompt('Find text in this file:');if(!q)return;let i=code.value.indexOf(q,code.selectionStart);if(i<0)i=code.value.indexOf(q);if(i<0){document.getElementById('status').textContent='Text not found.';return}code.focus();code.setSelectionRange(i,i+q.length);document.getElementById('status').textContent='Match selected.'}
function openFile(){document.getElementById('picker').click()}
document.getElementById('picker').addEventListener('change',e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{sync();let l=Object.keys(extensions).find(k=>f.name.endsWith('.'+extensions[k]))||'javascript';files.push({name:f.name,lang:l,text:String(r.result)});switchFile(files.length-1);document.getElementById('status').textContent='Opened '+f.name};r.readAsText(f);e.target.value=''});
function saveFile(){sync();persistWorkspace();if(window.CodeMaster){CodeMaster.saveText(currentName,code.value);document.getElementById('status').textContent='Saved '+currentName+' and workspace locally.';return}downloadFile()}
function downloadFile(){sync();let a=document.createElement('a'),u=URL.createObjectURL(new Blob([code.value],{type:'text/plain'}));a.href=u;a.download=currentName;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)}

const highlight=document.getElementById('highlight');
let assistantCode='';
function togglePanel(id){const el=document.getElementById(id);el.style.display=el.style.display==='none'?'block':'none';}
let codeHelpUnlocked=false;
function openCodeHelpGate(){if(codeHelpUnlocked){togglePanel('assistantPanel');return;}document.getElementById('codeHelpGate').style.display='block';document.getElementById('codeHelpPassword').value='';document.getElementById('codeHelpPasswordMessage').textContent='';setTimeout(()=>document.getElementById('codeHelpPassword').focus(),50);}
function closeCodeHelpGate(){document.getElementById('codeHelpGate').style.display='none';}
function unlockCodeHelp(){const field=document.getElementById('codeHelpPassword'),message=document.getElementById('codeHelpPasswordMessage');if(field.value==='ADMIN'){codeHelpUnlocked=true;closeCodeHelpGate();document.getElementById('assistantPanel').style.display='block';message.textContent='';}else{message.textContent='Incorrect password. Try again.';field.value='';field.focus();}}
function esc(s){return String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));}
function updateHighlight(){
 if(!highlight)return;
 const src=code.value;
 // Tokenize the original source exactly once. Never run highlighting regexes over
 // generated span markup; doing so used to expose fragments such as class="tok-str".
 const tokenPattern=/\/\/[^\n]*|#[^\n]*|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\b(?:function|return|const|let|var|if|else|for|while|class|public|private|static|void|int|float|double|string|String|new|import|from|def|print|true|false|null|None|include|using|namespace|auto)\b|\b\d+(?:\.\d+)?\b|\b[A-Za-z_$][\w$]*(?=\s*\()/g;
 let html='',last=0,match;
 while((match=tokenPattern.exec(src))!==null){
  html+=esc(src.slice(last,match.index));
  const token=match[0];
  let cls='tok-fn';
  if(token.startsWith('//')||token.startsWith('#'))cls='tok-comment';
  else if(token.startsWith('"')||token.startsWith("'"))cls='tok-str';
  else if(/^\d/.test(token))cls='tok-num';
  else if(/^(function|return|const|let|var|if|else|for|while|class|public|private|static|void|int|float|double|string|String|new|import|from|def|print|true|false|null|None|include|using|namespace|auto)$/.test(token))cls='tok-key';
  html+='<span class="'+cls+'">'+esc(token)+'</span>';
  last=tokenPattern.lastIndex;
 }
 html+=esc(src.slice(last));
 highlight.innerHTML=html+'\n';
 highlight.scrollTop=code.scrollTop;highlight.scrollLeft=code.scrollLeft;
}
code.addEventListener('input',updateHighlight);
code.addEventListener('scroll',()=>{highlight.scrollTop=code.scrollTop;highlight.scrollLeft=code.scrollLeft;numbers.scrollTop=code.scrollTop;});
function setVar(k,v){document.documentElement.style.setProperty(k,v)}
function applyAppearance(){let map={bgColor:['--bg','background'],editorColor:['--editor','editor'],textColor:['--syntax-text','text'],keyColor:['--syntax-key','key'],stringColor:['--syntax-string','string'],functionColor:['--syntax-fn','function'],commentColor:['--syntax-comment','comment'],numberColor:['--syntax-number','number']};Object.keys(map).forEach(id=>{let el=document.getElementById(id);if(el){let v=localStorage.getItem('cm_'+id)||el.value;el.value=v;if(id==='bgColor'){document.body.style.backgroundColor=v;if(!localStorage.getItem('cm_background_image'))document.body.style.backgroundImage='radial-gradient(ellipse at 85% 0,#25164a 0,transparent 35%)'}if(id==='editorColor')document.querySelectorAll('.editor,.output').forEach(x=>x.style.backgroundColor=v);if(id==='textColor')document.getElementById('code').style.color=v;setVar(map[id][0],v)}})}
['bgColor','editorColor','textColor','keyColor','stringColor','functionColor','commentColor','numberColor'].forEach(id=>{document.getElementById(id).addEventListener('input',e=>{localStorage.setItem('cm_'+id,e.target.value);applyAppearance();updateHighlight()})});
document.getElementById('backgroundPicker').addEventListener('change',e=>{let f=e.target.files&&e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{let img=new Image();img.onload=()=>{try{let max=1400,scale=Math.min(1,max/Math.max(img.width,img.height)),canvas=document.createElement('canvas');canvas.width=Math.round(img.width*scale);canvas.height=Math.round(img.height*scale);canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);let compact=canvas.toDataURL('image/jpeg',0.72);localStorage.setItem('cm_background_image',compact);document.body.style.backgroundImage='linear-gradient(#090e1d66,#090e1d66),url(\"'+compact+'\")';document.body.style.backgroundSize='cover';document.body.style.backgroundPosition='center';document.body.style.backgroundAttachment='fixed';document.getElementById('status').textContent='Background picture applied and saved on this device.'}catch(err){alert('Could not save this picture. Please choose another picture.')}};img.onerror=()=>alert('This picture could not be opened. Please choose another one.');img.src=String(r.result)};r.readAsDataURL(f);e.target.value=''});
function resetAppearance(){['bgColor','editorColor','textColor','keyColor','stringColor','functionColor','commentColor','numberColor','background_image'].forEach(k=>localStorage.removeItem('cm_'+k));document.body.style.backgroundImage='';document.body.style.backgroundColor='';document.querySelectorAll('#settingsPanel input[type=color]').forEach(x=>x.value=x.defaultValue);applyAppearance();updateHighlight()}
function codeForRequest(prompt,lang){
 const p=prompt.toLowerCase();
 const isHtml=lang==='html', isCss=lang==='css', isJs=lang==='javascript', isPy=lang==='python', isJava=lang==='java', isC=lang==='c', isCpp=lang==='cpp';
 const hello=examples[lang]||'';
 if(/calculator|add two numbers|addition/.test(p)){
  if(isPy)return 'a = float(input("Enter first number: "))\nb = float(input("Enter second number: "))\nprint("Sum:", a + b)';
  if(isJs)return 'const a = 12;\nconst b = 8;\nconsole.log("Sum:", a + b);';
  if(isJava)return 'public class Main {\n    public static void main(String[] args) {\n        int firstNumber = 12;\n        int secondNumber = 8;\n        int sum = firstNumber + secondNumber;\n        System.out.println("Sum: " + sum);\n    }\n}';
  if(isC)return '#include <stdio.h>\nint main(void) {\n int a = 12, b = 8;\n printf("Sum: %d\\n", a + b);\n return 0;\n}';
  if(isCpp)return '#include <iostream>\nint main() {\n int a = 12, b = 8;\n std::cout << "Sum: " << a + b << std::endl;\n return 0;\n}';
  if(isHtml)return '<!doctype html><html><body><h1>Simple Calculator</h1><input id="a" type="number" placeholder="First number"><input id="b" type="number" placeholder="Second number"><button onclick="document.getElementById(\'out\').textContent=Number(a.value)+Number(b.value)">Add</button><p id="out"></p></body></html>';
 }
 if(/multiplication table|times table/.test(p)){
  if(isPy)return 'number = 5\nfor i in range(1, 11):\n    print(f"{number} x {i} = {number * i}")';
  if(isJs)return 'const number = 5;\nfor (let i = 1; i <= 10; i++) {\n  console.log(`${number} x ${i} = ${number * i}`);\n}';
  if(isJava)return 'public class Main {\n    public static void main(String[] args) {\n        int number = 5;\n        for (int i = 1; i <= 10; i++) {\n            System.out.println(number + " x " + i + " = " + (number * i));\n        }\n    }\n}';
  if(isC)return '#include <stdio.h>\nint main(void) { int n=5; for(int i=1;i<=10;i++) printf("%d x %d = %d\\n",n,i,n*i); return 0; }';
  if(isCpp)return '#include <iostream>\nint main(){ int n=5; for(int i=1;i<=10;i++) std::cout<<n<<" x "<<i<<" = "<<n*i<<std::endl; return 0; }';
 }
 if(/loop|repeat/.test(p)){
  if(isPy)return 'for i in range(1, 6):\n    print(i)';
  if(isJs)return 'for (let i = 1; i <= 5; i++) {\n  console.log(i);\n}';
  if(isJava)return 'public class Main {\n    public static void main(String[] args) {\n        for (int i = 1; i <= 5; i++) {\n            System.out.println(i);\n        }\n    }\n}';
  if(isC)return '#include <stdio.h>\nint main(void){ for(int i=1;i<=5;i++) printf("%d\\n",i); return 0; }';
  if(isCpp)return '#include <iostream>\nint main(){ for(int i=1;i<=5;i++) std::cout<<i<<std::endl; return 0; }';
 }
 if(/hello|print|output|starter|basic/.test(p))return hello;
 if(isCss && /background|style|color|design|css/.test(p))return 'body {\n  font-family: Arial, sans-serif;\n  background: #eef4ff;\n  color: #18345c;\n  padding: 24px;\n}\nh1 { color: #286bd6; }';
 if(isHtml && /button|form|profile|portfolio|web page|website/.test(p))return '<!doctype html>\n<html>\n<head><meta name="viewport" content="width=device-width,initial-scale=1"><title>My Page</title></head>\n<body>\n  <h1>Welcome!</h1>\n  <p>My first web page.</p>\n  <button onclick="alert(\'Hello!\')">Click me</button>\n</body>\n</html>';
 if(/web page|website|heading|html page/.test(p)&&isHtml)return '<!doctype html>\n<html>\n<head><meta name="viewport" content="width=device-width,initial-scale=1"><title>My Page</title></head>\n<body>\n  <h1>Welcome!</h1>\n  <p>This is my first web page.</p>\n</body>\n</html>';
 return null;
}
function offlineHelp(prompt,lang){ return codeForRequest(prompt,lang); }
function cleanGeneratedCode(value){
 let text=String(value||'').trim();
 const match=text.match(/^```(?:[a-zA-Z0-9_+-]+)?\s*\n([\s\S]*?)\n```$/);
 if(match) text=match[1];
 return text;
}
async function generateWithAssistant(){
 const prompt=document.getElementById('aiPrompt').value.trim(),lang=language.value;
 const result=document.getElementById('aiResult'),explain=document.getElementById('aiExplanation');
 assistantCode='';
 if(!prompt){explain.textContent='Type a short description first.';result.textContent='';return;}
 result.textContent='Generating...';
 try{
  const endpoint=window.CODEMASTER_AI_ENDPOINT||'';
  if(/^https:\/\//i.test(endpoint)){
   const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt,language:lang,currentCode:code.value})});
   if(!response.ok)throw new Error('The AI service returned an error (HTTP '+response.status+').');
   const data=await response.json();
   assistantCode=cleanGeneratedCode(data.code||data.output||data.response||'');
   if(!assistantCode)throw new Error('The AI service returned no code.');
   explain.textContent=String(data.explanation||'Online AI response received. Check the code before running.');
  }else{
   assistantCode=cleanGeneratedCode(offlineHelp(prompt,lang)||'');
   if(!assistantCode){result.textContent='';explain.textContent='The offline helper does not have a matching template for that request. It will not show unrelated code. Full AI generation is unavailable until the app developer connects an online AI service.';return;}
   explain.textContent='Offline starter template generated. It is not a full AI model, so review and test the code.';
  }
  result.textContent=assistantCode;
 }catch(e){assistantCode='';result.textContent='';explain.textContent='Code Help could not generate code: '+e.message;}
}
async function copyAssistantCode(){
 if(!assistantCode){document.getElementById('aiExplanation').textContent='Generate code first.';return;}
 try{
  if(navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(assistantCode);
  else {const t=document.createElement('textarea');t.value=assistantCode;t.style.position='fixed';t.style.opacity='0';document.body.appendChild(t);t.select();const ok=document.execCommand('copy');t.remove();if(!ok)throw new Error('Copy unavailable');}
  document.getElementById('aiExplanation').textContent='Code copied. You can paste it into the editor.';
 }catch(e){document.getElementById('aiExplanation').textContent='Copy was blocked on this device. Use Insert into editor instead.';}
}
function runAssistantCode(){if(!assistantCode){document.getElementById('aiExplanation').textContent='Generate code first.';return;}insertAssistantResult();runCode();}

function insertAssistantResult(){if(!assistantCode){document.getElementById('aiExplanation').textContent='Generate code first.';return;}code.value=assistantCode;refreshLines();sync();updateHighlight();document.getElementById('status').textContent='Code inserted. Review it before running.';}


function init(){if(!restoreWorkspace()){code.value=examples.html;persistWorkspace()}else{let f=files[active];language.value=f.lang;currentName=f.name;code.value=f.text;document.getElementById('filename').textContent=currentName}refreshLines();renderTabs();applyAppearance();let bg=localStorage.getItem("cm_background_image");if(bg){document.body.style.backgroundImage='linear-gradient(#090e1d66,#090e1d66),url("'+bg+'")';document.body.style.backgroundSize="cover";document.body.style.backgroundPosition="center";document.body.style.backgroundAttachment="fixed";}updateHighlight()}
init();
