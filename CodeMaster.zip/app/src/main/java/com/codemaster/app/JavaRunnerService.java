package com.codemaster.app;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Process;
import android.os.RemoteException;

import bsh.Interpreter;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Runs a limited, beginner-friendly Java subset in a separate Android isolated process.
 * This is an interpreter, not a full javac/JVM implementation. Full Java is available online.
 */
public class JavaRunnerService extends Service {
    public static final int MSG_RUN = 1;
    public static final int MSG_RESULT = 2;
    private static final int MAX_SOURCE = 64 * 1024;
    private static final int MAX_OUTPUT = 32 * 1024;
    private static final long TIME_LIMIT_SECONDS = 4;

    private final Messenger incoming = new Messenger(new Handler(Looper.getMainLooper()) {
        @Override public void handleMessage(Message msg) {
            if (msg.what != MSG_RUN || msg.replyTo == null) return;
            Bundle data = msg.getData();
            String source = data.getString("source", "");
            String input = data.getString("input", "");
            Messenger reply = msg.replyTo;
            new Thread(() -> execute(source, input, reply), "CodeMaster-Java-Offline").start();
        }
    });

    @Override public IBinder onBind(Intent intent) { return incoming.getBinder(); }

    private void execute(String source, String input, Messenger reply) {
        String status = "ok";
        String output;
        if (source == null || source.length() > MAX_SOURCE) {
            status = "error";
            output = "Java source is too large for offline mode (64 KB maximum).";
        } else {
            FutureTask<String> task = new FutureTask<>(new Callable<String>() {
                @Override public String call() throws Exception { return interpret(source, input); }
            });
            Thread runner = new Thread(task, "CodeMaster-Java-Interpreter");
            runner.start();
            try {
                output = task.get(TIME_LIMIT_SECONDS, TimeUnit.SECONDS);
            } catch (TimeoutException e) {
                status = "error";
                output = "Offline Java stopped: the program exceeded the 4-second limit. Try a smaller loop or use Online Java.";
                task.cancel(true);
                send(reply, status, output);
                // This service runs in its own isolated process; terminate only that runner process.
                Process.killProcess(Process.myPid());
                return;
            } catch (ExecutionException e) {
                Throwable cause = e.getCause() == null ? e : e.getCause();
                status = "unsupported";
                output = "This program uses Java features not supported by Offline Java.\n" + safeMessage(cause)
                        + "\nChoose Online Java to run the full Java language.";
            } catch (Exception e) {
                status = "unsupported";
                output = "Offline Java could not interpret this program.\n" + safeMessage(e)
                        + "\nChoose Online Java to run the full Java language.";
            }
        }
        if (output.length() > MAX_OUTPUT) output = output.substring(0, MAX_OUTPUT) + "\n[Output truncated]";
        send(reply, status, output);
    }

    private String interpret(String source, String input) throws Exception {
        String body = extractMainBody(source);
        if (body == null) throw new UnsupportedOperationException("A public static void main(String[] args) method is required for offline mode.");

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        PrintStream capture = new PrintStream(bytes, true, "UTF-8");
        PrintStream oldOut = System.out;
        PrintStream oldErr = System.err;
        java.io.InputStream oldIn = System.in;
        try {
            System.setOut(capture);
            System.setErr(capture);
            System.setIn(new ByteArrayInputStream((input == null ? "" : input).getBytes(StandardCharsets.UTF_8)));
            Interpreter interpreter = new Interpreter();
            interpreter.setOut(capture);
            interpreter.setErr(capture);

            // Keep imports limited to the standard Java namespaces typically used in beginner exercises.
            Matcher imports = Pattern.compile("(?m)^\\s*import\\s+(?:static\\s+)?(?:java\\.(?:lang|util|math|io)\\.[A-Za-z0-9_.*]+)\\s*;").matcher(source);
            while (imports.find()) interpreter.eval(imports.group().trim());
            interpreter.eval(body);
            capture.flush();
            String result = bytes.toString("UTF-8");
            return result.isEmpty() ? "Program finished with no output.\n(Offline Java supports a beginner-friendly subset; use Online Java for advanced Java features.)" : result;
        } finally {
            System.setOut(oldOut);
            System.setErr(oldErr);
            System.setIn(oldIn);
            capture.close();
        }
    }

    /** Finds the body of main while ignoring braces inside strings and comments. */
    private static String extractMainBody(String source) {
        Matcher m = Pattern.compile("\\bmain\\s*\\(\\s*String\\s*\\[\\s*\\]\\s*[A-Za-z_$][A-Za-z0-9_$]*\\s*\\)\\s*\\{").matcher(source);
        if (!m.find()) return null;
        int open = source.indexOf('{', m.start());
        int depth = 0;
        boolean string = false, character = false, lineComment = false, blockComment = false, escape = false;
        for (int i = open; i < source.length(); i++) {
            char c = source.charAt(i), n = i + 1 < source.length() ? source.charAt(i + 1) : '\0';
            if (lineComment) { if (c == '\n') lineComment = false; continue; }
            if (blockComment) { if (c == '*' && n == '/') { blockComment = false; i++; } continue; }
            if (string || character) {
                if (escape) { escape = false; continue; }
                if (c == '\\') { escape = true; continue; }
                if (string && c == '"') string = false;
                if (character && c == '\'') character = false;
                continue;
            }
            if (c == '/' && n == '/') { lineComment = true; i++; continue; }
            if (c == '/' && n == '*') { blockComment = true; i++; continue; }
            if (c == '"') { string = true; continue; }
            if (c == '\'') { character = true; continue; }
            if (c == '{') depth++;
            else if (c == '}' && --depth == 0) return source.substring(open + 1, i);
        }
        return null;
    }

    private static String safeMessage(Throwable t) {
        String msg = t.getMessage();
        return msg == null || msg.trim().isEmpty() ? t.getClass().getSimpleName() : msg;
    }

    private static void send(Messenger reply, String status, String output) {
        try {
            Message result = Message.obtain(null, MSG_RESULT);
            Bundle b = new Bundle();
            b.putString("status", status);
            b.putString("output", output);
            result.setData(b);
            reply.send(result);
        } catch (RemoteException ignored) { }
    }
}
