# CodeMaster 5.0 – Professional Workspace Update

This is an upgraded Android Studio source project based on the supplied CodeMaster Android project. The original archive was left unchanged.

## Implemented in this update
- Local workspace autosave for open files using browser storage in the WebView.
- Restore the last open workspace after restarting the app.
- Create, rename and close source files.
- Export and import a CodeMaster project backup as JSON.
- Basic formatting (trailing whitespace cleanup) and find-in-file.
- Editor shortcuts: Ctrl/Cmd+S to save and Ctrl/Cmd+Enter to run.
- Automatic closing-pair insertion for brackets and quotes.
- App version updated to 5.0 (versionCode 7).

## Existing limitations retained
- Python and Java still depend on the existing native bridge/runtime and need device testing.
- C/C++ still use the configured online compiler; they are not offline.
- This update does not add a full language server, real debugger, Git client, or connected AI model.
- The current Code Help access password is embedded in the web asset and is not secure; APK users can extract it. Do not use it as real access control.
- A release APK has not been built or device-tested as part of this source update. Build it using the included GitHub Actions workflow or Android Studio, then test on target devices.

## Build
Open this folder in Android Studio or push it to the configured GitHub repository and run the included workflow.
