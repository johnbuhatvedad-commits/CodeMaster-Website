# CodeMaster – Mobile Workspace Update

## Changes in this update
- Added a password prompt before opening Code Help. Default password: `ADMIN`.
- Removed the Tools panel (kept the workspace customization controls).
- Adjusted editor and output dimensions for a balanced mobile layout. The editor uses a moderate responsive height and the output has a readable minimum height without taking over the screen.
- Improved formatting of the built-in Java examples.
- Added an `ios-web/` folder with a browser/PWA version, web manifest, and service worker for offline caching of the app shell.

## Important Java note
Java source normally needs a class and an entry-point method. This project's Java runner compiles the source and specifically looks for a class named `Main` with `public static void main(String[] args)`. Removing that class/main structure would make the generated Java program fail in this app. The templates are formatted more clearly, but the required Java structure remains.

## Password note
The default Code Help password is `ADMIN`. This is a basic in-app access prompt, not strong security: the password is stored in the client-side app code and can be discovered by someone who inspects the project. Do not use it to protect private data.

## iPhone / iPad support
An APK cannot be installed on iOS. Use the browser version in `ios-web/` instead:
1. Publish the contents of `ios-web/` on an HTTPS website (for example, a separate GitHub Pages site or a subfolder on your domain).
2. Open that HTTPS page in Safari on the iPhone/iPad.
3. Tap Share, then **Add to Home Screen**.
4. Launch CodeMaster from the new Home Screen icon.

The PWA caches its app shell and logo for offline opening after the first successful visit. Browser support differs from Android's native WebView bridge: HTML preview and JavaScript can run in Safari; Python and Java execution currently depend on the Android native bridge and will not run in the iOS browser build. C/C++ remote execution also requires an online compiler integration. Full AI generation still requires a developer-configured AI service; offline Code Help only supplies built-in starter templates.

## Build Android APK
Use the repository's GitHub Actions workflow (`Build CodeMaster Offline APK`) to build the Android project. This ZIP is source code, not a prebuilt APK. Test the resulting APK on the target Android devices before distributing it.
