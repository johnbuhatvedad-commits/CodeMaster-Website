# CodeMaster Android IDE — updated project

This project is based on the source ZIP whose editor page matched the uploaded APK. It keeps the original editor and adds the requested customization and optional assistant interface.

## Added in this update
- **Workspace customization:** choose background/editor/text colors, customize syntax token colors, and select a background picture. Preferences are stored locally on the device.
- **Syntax color preview:** highlights common keywords, strings, comments, numbers, and function names in the editor. This is a lightweight highlighter, not a full language parser.
- **Optional Code Assistant panel:** opened from **Tools** and clearly labeled as an optional learning tool.
  - Offline mode provides basic starter templates and common examples. It is not a downloaded local LLM and should not be described as full offline AI.
  - Online mode sends the prompt, selected language, and current source to a user-configured HTTPS backend. The backend must return JSON containing `code`, `output`, or `response`.
  - Do not put a private AI provider key in the APK. Keep provider credentials on the backend server.
- **Python runner correction:** execution now runs through a dedicated Chaquopy Python module and captures both standard output and errors.
- **Native callback correction:** newline escaping in Java-to-WebView output is corrected.

## Language support status
- HTML/CSS: local WebView preview.
- JavaScript: local execution in the WebView.
- Python: Chaquopy 3.11 embedded runtime.
- Java: Janino in-memory compiler; supports a Java subset, not a complete JDK.
- C/C++: still not executable offline in this project. A real offline compiler requires Android-compatible compiler binaries and runtime libraries for supported ABIs. This source does not pretend those are present.

## Online assistant backend contract
The app sends an HTTPS `POST` request with JSON:

```json
{
  "prompt": "user request",
  "language": "python",
  "currentCode": "..."
}
```

The configured backend should respond with JSON such as:

```json
{ "code": "print('Hello')" }
```

The endpoint must implement authentication and call the AI provider securely on the server. The app does not include a provider API key or a ready-made backend URL.

## Build an APK
1. Upload the contents of this folder to the root of your GitHub repository.
2. Push to `main`/`master`, or open **Actions → Build CodeMaster Offline APK**.
3. Download the `CodeMaster-debug-APK` artifact and extract `app-debug.apk`.

The repository workflow installs Gradle and Android SDK dependencies in GitHub Actions. This environment did not run an Android Gradle build, so the generated project ZIP is source code and has not yet been verified as a installable APK.

## Important notes
- The app does not need internet for its local editor, Python, Java, or offline helper. Online assistant mode requires a network connection and a configured HTTPS backend.
- Janino supports a subset of Java; it is not `javac`.
- The assistant is optional and clearly identified. Follow your teacher's rules about when AI tools may be used.
- This is a learning IDE, not a hardened sandbox. Only run code you wrote or trust.
